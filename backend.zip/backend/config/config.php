<?php
return [
  'db' => [
    'host' => '127.0.0.1',
    'user' => 'root',
    'pass' => '',
    'name' => 'solar_burji_db',
    'port' => 3306
  ],
  'api_key' => 'dev123'
];
