<?php
// Copy this file to config.php and fill in values.
return [
  'db' => [
    'host' => '127.0.0.1',
    'user' => 'root',
    'pass' => '',
    'name' => 'solar_burji_db',
    'port' => 3306
  ],
  // Simple API key; set the same value in the Flutter app headers
  'api_key' => 'CHANGE_ME_API_KEY'
];
