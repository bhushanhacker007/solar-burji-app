<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/helpers.php';
send_cors_headers();
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }
require_api_key($config);

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
  $body = read_json_body();
  $reading_date = $body['reading_date'] ?? null; // YYYY-MM-DD
  $import_kwh = (float)($body['import_kwh'] ?? 0);
  $export_kwh = (float)($body['export_kwh'] ?? 0);
  $generation_kwh = (float)($body['generation_kwh'] ?? 0);
  $notes = $body['notes'] ?? null;

  if (!$reading_date) {
    send_json(['error' => 'reading_date required (YYYY-MM-DD)'], 400);
  }

  $stmt = $mysqli->prepare('INSERT INTO solar_daily (reading_date, import_kwh, export_kwh, generation_kwh, notes) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE import_kwh = VALUES(import_kwh), export_kwh = VALUES(export_kwh), generation_kwh = VALUES(generation_kwh), notes = VALUES(notes)');
  $stmt->bind_param('sddds', $reading_date, $import_kwh, $export_kwh, $generation_kwh, $notes);
  if (!$stmt->execute()) {
    send_json(['error' => 'DB error', 'detail' => $stmt->error], 500);
  }
  send_json(['ok' => true]);
}

if ($method === 'GET') {
  // GET /api/solar.php?period=day|week|month&date=YYYY-MM-DD or start_date&end_date
  [$start, $end] = get_date_range();
  $stmt = $mysqli->prepare('SELECT reading_date, import_kwh, export_kwh, generation_kwh, notes FROM solar_daily WHERE reading_date BETWEEN ? AND ? ORDER BY reading_date ASC');
  $stmt->bind_param('ss', $start, $end);
  if (!$stmt->execute()) {
    send_json(['error' => 'DB error', 'detail' => $stmt->error], 500);
  }
  $res = $stmt->get_result();
  $rows = [];
  $tot_import = 0; $tot_export = 0; $tot_gen = 0;
  while ($r = $res->fetch_assoc()) {
    $rows[] = $r;
    $tot_import += (float)$r['import_kwh'];
    $tot_export += (float)$r['export_kwh'];
    $tot_gen += (float)$r['generation_kwh'];
  }
  send_json([
    'range' => ['start' => $start, 'end' => $end],
    'total_import_kwh' => round($tot_import, 3),
    'total_export_kwh' => round($tot_export, 3),
    'total_generation_kwh' => round($tot_gen, 3),
    'days' => $rows
  ]);
}

send_json(['error' => 'Method not allowed'], 405);
