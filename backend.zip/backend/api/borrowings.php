<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/helpers.php';
send_cors_headers();
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }
require_api_key($config);

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
  $body = read_json_body();
  $txn_date = $body['txn_date'] ?? null; // YYYY-MM-DD
  $customer_name = $body['customer_name'] ?? null;
  $amount = isset($body['amount']) ? (float)$body['amount'] : null;
  $is_repayment = (int)($body['is_repayment'] ?? 0);
  $note = $body['note'] ?? null;

  if (!$txn_date || !$customer_name || $amount === null) {
    send_json(['error' => 'txn_date, customer_name, amount required'], 400);
  }
  if ($is_repayment !== 0 && $is_repayment !== 1) {
    send_json(['error' => 'is_repayment must be 0 or 1'], 400);
  }

  $stmt = $mysqli->prepare('INSERT INTO borrowings (txn_date, customer_name, amount, is_repayment, note) VALUES (?, ?, ?, ?, ?)');
  $stmt->bind_param('ssdis', $txn_date, $customer_name, $amount, $is_repayment, $note);
  if (!$stmt->execute()) {
    send_json(['error' => 'DB error', 'detail' => $stmt->error], 500);
  }
  send_json(['ok' => true, 'id' => $mysqli->insert_id]);
}

if ($method === 'GET') {
  [$start, $end] = get_date_range();
  $stmt = $mysqli->prepare('SELECT txn_date, customer_name, amount, is_repayment, note FROM borrowings WHERE txn_date BETWEEN ? AND ? ORDER BY txn_date ASC, id ASC');
  $stmt->bind_param('ss', $start, $end);
  if (!$stmt->execute()) {
    send_json(['error' => 'DB error', 'detail' => $stmt->error], 500);
  }
  $res = $stmt->get_result();
  $rows = [];
  $borrow_total = 0; $repayment_total = 0;
  while ($r = $res->fetch_assoc()) {
    $rows[] = $r;
    if ((int)$r['is_repayment'] === 1) {
      $repayment_total += (float)$r['amount'];
    } else {
      $borrow_total += (float)$r['amount'];
    }
  }
  send_json([
    'range' => ['start' => $start, 'end' => $end],
    'borrow_total' => round($borrow_total, 2),
    'repayment_total' => round($repayment_total, 2),
    'net_outstanding_change' => round($borrow_total - $repayment_total, 2),
    'entries' => $rows
  ]);
}

send_json(['error' => 'Method not allowed'], 405);
